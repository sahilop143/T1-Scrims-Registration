let registeredTeams = [];
let takenErangelDrops = new Set();
let takenMiramarDrops = new Set();
let takenSanhokDrops = new Set();

let erangelLocations = ["Pochinki", "Rozhok", "Yasnaya Polyana", "Georgopol (North)", "Georgopol (South)", "Novorepnoye", "Primorsk", "Lipovka", "Severny", "Mylta", "Mylta Power", "Zharki", "Farm", "Mansion", "Shelter", "School", "Apartments", "Hospital", "Shooting Range", "Kameshki"];
let miramarLocations = ["Los Leones", "El Pozo", "Monte Nuevo", "Valle del Mar", "La Cobrería", "San Martin", "Chumacera", "Pecado", "Campo Militar", "Tierra Bronca", "Cruz del Valle", "Impala", "Puerto Paraíso", "La Bendita", "Minas Generales", "Minas del Sur", "Power Grid", "Water Treatment", "Hacienda del Patrón"];
let sanhokLocations = ["Bootcamp", "Paradise Resort", "Pai Nan", "Kampong", "Tat Mok", "Sahmee", "Lakawi", "Ban Tai", "Mongnai", "Ha Tinh", "Khao", "Na Kham", "Ruins", "Cave", "Docks", "Quarry", "Tambang", "Lakawi", "Narathi"];

function populateDropOptions() {
    updateDropOptions("erangelDrop", erangelLocations, takenErangelDrops);
    updateDropOptions("miramarDrop", miramarLocations, takenMiramarDrops);
    updateDropOptions("sanhokDrop", sanhokLocations, takenSanhokDrops);
}

function updateDropOptions(selectId, locations, takenSet) {
    let select = document.getElementById(selectId);
    select.innerHTML = locations
        .filter(loc => !takenSet.has(loc))
        .map(loc => `<option value="${loc}">${loc}</option>`)
        .join("");
}

function registerTeam() {
    if (registeredTeams.length >= 20) {
        alert("Registration full! Maximum 20 teams allowed.");
        return;
    }

    let teamName = document.getElementById("teamName").value.trim();
    let erangelDrop = document.getElementById("erangelDrop").value;
    let miramarDrop = document.getElementById("miramarDrop").value;
    let sanhokDrop = document.getElementById("sanhokDrop").value;
    let time = new Date().toLocaleString();
    let cancelCode = Math.random().toString(36).substr(2, 8);

    if (!teamName || !erangelDrop || !miramarDrop || !sanhokDrop) {
        alert("Please fill all fields!");
        return;
    }

    if (registeredTeams.some(team => team.teamName.toLowerCase() === teamName.toLowerCase())) {
        alert("Team name already registered!");
        return;
    }

    registeredTeams.push({ teamName, erangelDrop, miramarDrop, sanhokDrop, time, cancelCode });
    takenErangelDrops.add(erangelDrop);
    takenMiramarDrops.add(miramarDrop);
    takenSanhokDrops.add(sanhokDrop);

    updateSlotList();
    populateDropOptions();
    alert("Registration successful! Your cancellation code is: " + cancelCode);
}

function cancelSlot() {
    let cancelCode = prompt("Enter your cancellation code:");
    let index = registeredTeams.findIndex(team => team.cancelCode === cancelCode);

    if (index !== -1) {
        let team = registeredTeams[index];
        takenErangelDrops.delete(team.erangelDrop);
        takenMiramarDrops.delete(team.miramarDrop);
        takenSanhokDrops.delete(team.sanhokDrop);

        registeredTeams.splice(index, 1);
        updateSlotList();
        populateDropOptions();
        alert("Slot cancelled successfully.");
    } else {
        alert("Invalid cancellation code!");
    }
}

function updateSlotList() {
    let table = document.getElementById("slotList");
    table.innerHTML = `
        <tr>
            <th>Slot #</th>
            <th>Team Name</th>
            <th>Erangel</th>
            <th>Miramar</th>
            <th>Sanhok</th>
            <th>Registration Time</th>
            <th>Cancel Slot</th>
        </tr>
    `;

    registeredTeams.forEach((team, index) => {
        let row = `
            <tr>
                <td>${index + 3}</td>
                <td>${team.teamName}</td>
                <td>${team.erangelDrop}</td>
                <td>${team.miramarDrop}</td>
                <td>${team.sanhokDrop}</td>
                <td>${team.time}</td>
                <td><button onclick="cancelSlot()">Cancel</button></td>
            </tr>
        `;
        table.innerHTML += row;
    });
}

populateDropOptions();
